var mongoose=require("mongoose");
var passportlocalmongoose=require("passport-local-mongoose");
var UserSchema=mongoose.Schema({
    name:String,
    email: String,
    password: String,
    phone:String
    
});

UserSchema.plugin(passportlocalmongoose);
module.exports=mongoose.model("User", UserSchema);