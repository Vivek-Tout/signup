var express=require("express"); 
var bodyParser=require("body-parser"); 
//new
var passport = require("passport");
    var bodyParser = require("body-parser");
    var LocalStrategy = require("passport-local");
    var passportLocalMongoose = require("passport-local-mongoose");//end
const mongoose = require('mongoose'); 
const User = require('./models/user'); 
//new
mongoose.set('useNewUrlParser', true); 
mongoose.set('useFindAndModify', false); 
mongoose.set('useCreateIndex', true); 
mongoose.set('useUnifiedTopology', true); //end
mongoose.connect('mongodb://localhost:27017/gfg'); 
var db=mongoose.connection; 
db.on('error', console.log.bind(console, "connection error")); 
db.once('open', function(callback){ 
  console.log("connection succeeded visit http://localhost:8081/"); 
}) 

var app=express() 
app.use(express.static(__dirname));


app.use(bodyParser.json()); 
app.use(express.static('public')); 
app.use(bodyParser.urlencoded({ 
  extended: true
})); 
//new 
app.use(passport.initialize()); 
app.use(passport.session()); 
  
passport.use(new LocalStrategy(User.authenticate())); 
passport.serializeUser(User.serializeUser()); 
passport.deserializeUser(User.deserializeUser()); 

//new end

app.post('/sign_up', function(req,res){ 
  var name = req.body.name; 
  var email =req.body.email; 
  var pass = req.body.password; 
  var phone =req.body.phone; 

  var data = { 
    "name": name, 
    "email":email, 
    "password":pass, 
    "phone":phone 
  } 
db.collection('details').insertOne(data,function(err, collection){ 
    if (err) throw err; 
    console.log("Record inserted Successfully"); 
      
  }); 
    
  return res.redirect('signup_success.html'); 
}) 

app.post('/login_user',passport.authenticate('local', { 
  successRedirect: '/login_success.html', 
  failureRedirect: '/login_issue.html'
}), function(req,res)
{
  
});

app.get('/',function(req,res){ 

return res.redirect('login.html'); 
}).listen(8081) 


console.log("server listening at port 8081 "); 
